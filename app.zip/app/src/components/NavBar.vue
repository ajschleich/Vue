<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-light align-center">
    <div class="container">
      <a class="navbar-brand" href="#">VueApp for Clarity</a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <router-link class="nav-link" to="/">Travling the USA</router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/secondtrip"
              >2nd Trip</router-link
            >
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/thirdtrip">3rd Trip</router-link>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</template>

<script>
export default {
  name: "NavBar",
};
</script>
