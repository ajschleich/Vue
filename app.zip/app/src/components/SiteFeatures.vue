<!-- src/components/SiteFeatures.vue -->
<template>
  <div>
    <img src="@/assets/3.jpg" alt="Features Image" class="img-fluid rounded" />
    <h1>Welcome to the 2nd trip Page</h1>
    <p>This is the 2nd trip page of our Vue App.</p>
  </div>
</template>

<script>
export default {
  name: "SiteFeatures",
};
</script>
