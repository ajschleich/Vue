<template>
  <li :class="{ 'list-group-item': true, completed: todo.completed }">
    <div class="form-check">
      <div
        class="d-flex flex-direction-row justify-content-between align-items-center"
      >
        <div>
          <input
            class="form-check-input"
            type="checkbox"
            :checked="todo.completed"
            @change="toggleCompleted"
          />
          <label class="form-check-label">
            {{ todo.text }}
          </label>
        </div>
        <div>
          <button class="btn btn-danger btn-sm" @click="deleteTodo">
            Delete
          </button>
        </div>
      </div>
    </div>
  </li>
</template>

<script>
export default {
  props: ["todo"],
  methods: {
    toggleCompleted() {
      this.$emit("toggle-completed", this.todo.id);
    },
    deleteTodo() {
      this.$emit("delete-todo", this.todo.id);
    },
  },
};
</script>

<style scoped>
.completed {
  text-decoration: line-through;
}
</style>
