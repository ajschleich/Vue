<!-- src/components/SitePricing.vue -->
<template>
  <div>
    <img src="@/assets/2.jpg" alt="Pricing Image" class="img-fluid rounded" />
    <h1>Welcome to the 3rd Trip Page</h1>
    <p>This is the 3rd trip page of our App.</p>
  </div>
</template>

<script>
export default {
  name: "SitePricing",
};
</script>
