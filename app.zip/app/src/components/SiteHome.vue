<!-- src/components/SiteHome.vue -->
<template>
  <div>
    <img src="@/assets/1.jpg" alt="Home Image" class="img-fluid rounded" />
    <h1>Travling the USA</h1>
    <p>
      This is the my new app that will help remember what to pack for each
      destination.
    </p>
  </div>
</template>

<script>
export default {
  name: "SiteHome",
};
</script>
