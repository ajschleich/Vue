<template>
  <div>
    <navbar></navbar>
    <div class="container mt-3">
      <div class="row">
        <div class="col-md-8">
          <!-- Router-view should be here to render routed components -->
          <router-view></router-view>
        </div>
        <div class="col-md-4">
          <h2>Things to Pack</h2>
          <input
            v-model="newTodoText"
            @keyup.enter="addTodo"
            placeholder="Add a new task"
            class="form-control mb-2"
          />
          <ul class="list-group">
            <todo-item
              v-for="todo in todos"
              :key="todo.id"
              :todo="todo"
              @delete-todo="handleDeleteTodo"
              @toggle-completed="handleToggleCompleted"
            ></todo-item>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Navbar from "./components/NavBar.vue";
import TodoItem from "./components/TodoItem.vue";

export default {
  components: {
    Navbar,
    TodoItem,
  },
  data() {
    return {
      newTodoText: "",
      todos: [
        { id: 1, text: "Identification and Passes", completed: false },
        { id: 2, text: "Cash on Hand", completed: false },
      ],
      nextTodoId: 3,
    };
  },
  methods: {
    addTodo() {
      if (this.newTodoText.trim()) {
        this.todos.push({
          id: this.nextTodoId++,
          text: this.newTodoText,
          completed: false,
        });
        this.newTodoText = ""; // Clear the input after adding
      }
    },
    handleDeleteTodo(id) {
      this.todos = this.todos.filter((todo) => todo.id !== id);
    },
    handleToggleCompleted(id) {
      const todo = this.todos.find((todo) => todo.id === id);
      todo.completed = !todo.completed;
    },
  },
};
</script>

<style>
router-view {
  border: 2px solid red; /* This will put a red border around the router-view */
}
</style>
