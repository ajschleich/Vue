// Import necessary libraries and components
import { createApp } from "vue"; // Imports the Vue 3 `createApp` function.
import App from "./App.vue"; // Imports the root component App.vue.
import "./global.scss"; // Imports global styles for your application.
import "bootstrap/dist/js/bootstrap.bundle.min.js"; // Imports Bootstrap JS for component interaction.
import router from "./router"; // Imports the Vue Router configuration.

// Create a new Vue application instance
const app = createApp(App);

// Use plugins with the Vue application
app.use(router); // Tell Vue to use the Vue Router for navigation.

// Mount the Vue application to the DOM
app.mount("#app"); // Mounts Vue app to the element with the id of 'app' in your HTML.
