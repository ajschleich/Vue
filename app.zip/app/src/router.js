import { createRouter, createWebHistory } from "vue-router";
import SiteHome from "./components/SiteHome.vue";
import SiteFeatures from "./components/SiteFeatures.vue";
import SitePricing from "./components/SitePricing.vue";

const routes = [
  {
    path: "/",
    name: "Travling the USA",
    component: SiteHome,
  },
  {
    path: "/secondtrip",
    name: "2nd Trip",
    component: SiteFeatures,
  },
  {
    path: "/thirdtrip",
    name: "3rd Trip",
    component: SitePricing,
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
